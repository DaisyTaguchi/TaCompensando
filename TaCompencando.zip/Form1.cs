﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaCompencando
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double a = double.Parse(TextBoxEtanol.Text);
            double b = double.Parse(TextBoxGas.Text);

            int i = 0;

            if (i > 0.7)
            {
                //LabelKmLGasolina = true;

            }
            else  if(i < 0.7)
            {
                //labelResKmLEtanol = true;
            }



        }
               

        private void TxtBoxKmEtanol(object sender, EventArgs e)
        {

        }

        private void TxtBoxKmGas(object sender, EventArgs e)
        {

        }

        private void TxtBoxRsEtanol(object sender, EventArgs e)
        {

        }

        private void TxtBoxRsGas(object sender, EventArgs e)
        {

        }

        private void TxtKlEtanol(object sender, EventArgs e)
        {

        }

        private void TxtKlGas(object sender, EventArgs e)
        {

        }

        private void TxtBoxRelEtaGas(object sender, EventArgs e)
        {
            if (Text == "Etanol")
                MessageBox.Show("Tá compensando Etanol");
            else
                MessageBox.Show("Tá compensando Gasolina");
        }
    }
}
